# Assignment 1 — DOSM Household Income and Poverty

**Group ID: A**

## Members and focus states

Focus states are assigned by sorting matric numbers in ascending order, applying `% 16` to the alphabetically sorted 16-state list, and moving forward to the next unused state if a collision occurs.

| Name | Matric number | Focus state | Role status |
|---|---:|---|---|
| NUR AINA MAISARAH BINTI MUHAMADNIZAM | 306701 | W.P. Kuala Lumpur | Role 4 — Matrix Analyst B |
| THARSHWEIN RAMAKRISHNAN | 308376 | Pulau Pinang | Role 5 —  Integration and Test Lead |
| NUR ASHILA AHSHA BINTI ABU BAKAR | 313149 | W.P. Labuan | Role 1 — Data Steward  |
| REENASRI RAJAMANI | 313366 | Perak | Role 2 — Structures Engineer |
| MUHAMMAD IRFAN FIRDAUS BIN DAAHLAN | 314465 | Kedah | Role 3 — Matrix Analyst A |

## Setup and run

1. Use Python 3.11 or newer.
2. Install dependencies: `python -m pip install -r requirements.txt`.
3. Open `assignment1.ipynb` and run all cells from a fresh kernel.
4. This draft currently reads the supplied CSV files with Python's standard-library `csv` module. **Before final submission**, use the lecturer-provided, unedited `fetch_data.py` and the original `hh_income_state.json` and `hh_poverty_state.json` files in `data/raw/`, as required by the assignment brief. Do not submit an edited copy of `fetch_data.py`.
5. Confirm all group roles, data download date, fallback-file status, and contribution/review notes with the group.

## Data status

The current working draft uses the two CSV files supplied in this conversation, copied into `data/raw/`. These are not the official JSON files required for final submission. The CSV metadata does not provide a data download date. LMS fallback files used: not confirmed.

## Completion checklist

- [x] Group ID and matric numbers entered
- [x] Focus states calculated and entered
- [x] Confirm all five roles with the group
- [x] Replace draft CSV loading path with the official JSON files and lecturer-provided loader
- [x] Record the actual data download date and whether LMS fallback files were used
- [x] Run notebook from a fresh kernel using the final data
- [x] Confirm at least ten meaningful assertions pass, including the real-matric-number focus-state test
- [x] Complete Task 5.3 interpretation after reviewing generated results
- [x] Complete contributions and AI-use disclosure accurately
- [x] Check references, then create `A1_A.zip` with the exact required structure

## References

- Department of Statistics Malaysia (DOSM), *Household Income by State*, https://data.gov.my/data-catalogue/hh_income_state (CC BY 4.0).
- Department of Statistics Malaysia (DOSM), *Poverty by State*, https://data.gov.my/data-catalogue/hh_poverty_state (CC BY 4.0).
- Add the exact title and URL of the HIES technical notes consulted for the poverty methodology discussion.
- Add any package documentation or external explanations used.
