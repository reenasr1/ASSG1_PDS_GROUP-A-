"""Shared functions for Assignment 1: DOSM household income and poverty."""
from __future__ import annotations
import json
import numpy as np

SURVEY_YEARS = [2016, 2019, 2020, 2022, 2024]
POVERTY_YEARS = [2019, 2020, 2022, 2024]
REGIONS = {
    "Northern": ["Perlis", "Kedah", "Pulau Pinang", "Perak"],
    "Central": ["Selangor", "W.P. Kuala Lumpur", "W.P. Putrajaya", "Negeri Sembilan"],
    "Southern": ["Melaka", "Johor"],
    "East Coast": ["Kelantan", "Terengganu", "Pahang"],
    "East Malaysia": ["Sabah", "Sarawak", "W.P. Labuan"],
}


def survey_year(record: dict) -> int:
    """Extract the year from the first four characters of date.

    Owner: NUR ASHILA AHSHA BINTI ABU BAKAR (role 1). Reviewed by: REENASRI RAJAMANI (role 2).
    """
    try:
        return int(str(record["date"])[:4])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"Record has an invalid or missing date: {record!r}") from exc


def validate_records(records: list[dict], required_keys: tuple[str, ...]) -> None:
    """Validate keyed records and reject duplicate (state, date) pairs.

    Owner: NUR ASHILA AHSHA BINTI ABU BAKAR (role 1). Reviewed by: REENASRI RAJAMANI (role 2).
    """
    if not isinstance(records, list):
        raise TypeError("records must be a list")
    if not records:
        raise ValueError("records must not be empty")
    seen = set()
    for i, record in enumerate(records):
        if not isinstance(record, dict):
            raise TypeError(f"record at index {i} is not a dictionary")
        missing = [key for key in required_keys if key not in record]
        if missing:
            raise ValueError(f"record at index {i} is missing required keys: {missing}")
        if "state" in record and "date" in record:
            key = (record["state"], record["date"])
            if key in seen:
                raise ValueError(f"duplicate (state, date) key: {key}")
            seen.add(key)


def index_by_key(records: list[dict]) -> dict[tuple[str, int], dict]:
    """Index records by (state, year), rejecting duplicate keys.

    Owner: REENASRI RAJAMANI (role 2). Reviewed by: NUR ASHILA AHSHA BINTI ABU BAKAR (role 1).
    """
    result = {}
    for record in records:
        key = (record["state"], survey_year(record))
        if key in result:
            raise ValueError(f"duplicate (state, year) key: {key}")
        result[key] = record
    return result


def join_records(income_records: list[dict], poverty_records: list[dict]):
    """Join on (state, year); return joined records and keys unique to each dataset.

    Owner: REENASRI RAJAMANI (role 2). Reviewed by: NUR ASHILA AHSHA BINTI ABU BAKAR (role 1).
    """
    income = index_by_key(income_records)
    poverty = index_by_key(poverty_records)
    common = income.keys() & poverty.keys()
    joined = [{**income[key], "poverty_record": poverty[key]} for key in sorted(common)]
    return joined, sorted(income.keys() - poverty.keys()), sorted(poverty.keys() - income.keys())


def to_float(value) -> float:
    """Convert None to np.nan and other numeric values to float.

    Owner: REENASRI RAJAMANI (role 2). Reviewed by: NUR ASHILA AHSHA BINTI ABU BAKAR (role 1).
    """
    return np.nan if value is None or value == "" else float(value)


def focus_states(matric_numbers: list[int], states: list[str]) -> list[str]:
    """Assign distinct focus states by sorted matric number and modulo-16 rule.

    Owner: NUR ASHILA AHSHA BINTI ABU BAKAR (role 1). Reviewed by: REENASRI RAJAMANI (role 2).
    """
    if len(states) != 16 or len(set(states)) != 16:
        raise ValueError("states must contain exactly 16 distinct state names")
    if len(matric_numbers) > 16:
        raise ValueError("cannot assign unique focus states to more than 16 members")
    assigned, used = [], set()
    for matric in sorted(int(x) for x in matric_numbers):
        start = int(matric) % 16
        for offset in range(16):
            candidate = states[(start + offset) % 16]
            if candidate not in used:
                assigned.append(candidate)
                used.add(candidate)
                break
    return assigned


def records_to_matrices(income_records: list[dict], poverty_records: list[dict]):
    """Build alphabetical STATES and the required float matrices.

    Owner: REENASRI RAJAMANI (role 2). Reviewed by: NUR ASHILA AHSHA BINTI ABU BAKAR (role 1).
    """
    states = sorted({r["state"] for r in income_records})
    if len(states) != 16:
        raise ValueError(f"expected 16 states in income data, found {len(states)}")
    income = index_by_key(income_records)
    poverty = index_by_key(poverty_records)
    median = np.array([[to_float(income.get((s, y), {}).get("income_median")) for y in SURVEY_YEARS] for s in states], dtype=float)
    mean = np.array([[to_float(income.get((s, y), {}).get("income_mean")) for y in SURVEY_YEARS] for s in states], dtype=float)
    poverty_matrix = np.array([[to_float(poverty.get((s, y), {}).get("poverty_absolute")) for y in POVERTY_YEARS] for s in states], dtype=float)
    return states, median, mean, poverty_matrix


def focus_state_analysis(state: str, states: list[str], median: np.ndarray, mean: np.ndarray):
    """Return labelled vector calculations for one focus state.

    Owner: NUR ASHILA AHSHA BINTI ABU BAKAR (role 1). Reviewed by: MUHAMMAD IRFAN FIRDAUS BIN DAAHLAN (role 3).
    """
    if state not in states:
        raise ValueError(f"unknown state: {state}")
    row = median[states.index(state), :]
    gaps = np.diff(np.asarray(SURVEY_YEARS, dtype=int))
    change = np.diff(row)
    pct = change / row[:-1] * 100
    per_year = change / gaps
    labels = [f"{SURVEY_YEARS[i]}-{SURVEY_YEARS[i+1]}" for i in range(len(gaps))]
    fell = [labels[i] for i in np.where(change < 0)[0]]
    mean_median_gap = mean[states.index(state), :] - row
    return {"state": state, "periods": labels, "change": change, "percentage_change": pct,
            "change_per_year": per_year, "periods_median_fell": fell, "mean_minus_median": mean_median_gap}


def region_map(regions: dict[str, list[str]], states: list[str]) -> dict[str, str]:
    """Map each state to exactly one region and reject missing/duplicate states.

    Owner: NUR AINA MAISARAH BINTI MUHAMADNIZAM (role 4). Reviewed by: MUHAMMAD IRFAN FIRDAUS BIN DAAHLAN (role 3).
    """
    mapping, duplicates = {}, set()
    for region, members in regions.items():
        for state in members:
            if state in mapping:
                duplicates.add(state)
            mapping[state] = region
    missing, extra = set(states) - set(mapping), set(mapping) - set(states)
    if duplicates or missing or extra:
        raise ValueError(f"invalid region mapping; duplicated={sorted(duplicates)}, missing={sorted(missing)}, extra={sorted(extra)}")
    return mapping


def task4_flag_matrix(median: np.ndarray, poverty: np.ndarray) -> np.ndarray:
    """Flag periods when median income rises but absolute poverty does not fall.

    Owner: NUR AINA MAISARAH BINTI MUHAMADNIZAM (role 4). Reviewed by: THARSHWEIN RAMAKRISHNAN  (role 5).
    """
    median_rises = np.diff(median[:, 1:], axis=1) > 0
    poverty_does_not_fall = np.diff(poverty, axis=1) >= 0
    return median_rises & poverty_does_not_fall


def build_state_profile(state: str, states: list[str], years: list[int], median: np.ndarray,
                        mean: np.ndarray, poverty: np.ndarray, poverty_years: list[int],
                        regions: dict[str, list[str]]) -> dict:
    """Return a JSON-serializable state profile without relying on global variables.

    Owner: NUR AINA MAISARAH BINTI MUHAMADNIZAM (role 4). Reviewed by: THARSHWEIN RAMAKRISHNAN  (role 5).
    """
    if state not in states:
        raise ValueError(f"unknown state: {state}")
    mapping = region_map(regions, states)
    idx = states.index(state)
    latest_year = years[-1]
    benchmark = float(np.nanmedian(median[:, -1]))
    latest_index = float(median[idx, -1] / benchmark)
    ranks = np.argsort(np.argsort(-median[:, -1], kind="stable"), kind="stable") + 1
    region_rows = np.array([s in regions[mapping[state]] for s in states], dtype=bool)
    region_latest_mean = float(np.nanmean(median[region_rows, -1]))
    flag_matrix = task4_flag_matrix(median, poverty)
    profile = {
        "state": state, "region": mapping[state],
        "income_by_year": [{"year": int(y), "median": _json_num(median[idx, j]), "mean": _json_num(mean[idx, j])} for j, y in enumerate(years)],
        "growth_first_to_last_percent": _json_num((median[idx, -1] / median[idx, 0] - 1) * 100),
        "latest_year": int(latest_year), "relative_income_index_latest": _json_num(latest_index),
        "relative_income_rank_latest": int(ranks[idx]), "region_mean_median_latest": region_latest_mean,
        "above_region_mean_latest": bool(median[idx, -1] > region_latest_mean),
        "absolute_poverty_by_year": [{"year": int(y), "rate": _json_num(poverty[idx, j])} for j, y in enumerate(poverty_years)],
        "flagged_periods": [period for period, flagged in zip(["2019-2020", "2020-2022", "2022-2024"], flag_matrix[idx].tolist()) if flagged],
    }
    return profile


def _json_num(value):
    value = float(value)
    return None if np.isnan(value) else value
